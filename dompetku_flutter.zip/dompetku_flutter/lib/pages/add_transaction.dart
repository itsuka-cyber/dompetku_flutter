import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../models.dart';
import '../nav.dart';
import '../state/finance_store.dart';
import '../state/toast.dart';
import '../theme.dart';
import '../utils.dart';
import '../widgets/common.dart';
import '../widgets/icons.dart';

class AddTransactionPage extends StatefulWidget {
  const AddTransactionPage({super.key});

  @override
  State<AddTransactionPage> createState() => _AddTransactionPageState();
}

class _AddTransactionPageState extends State<AddTransactionPage> {
  final TextEditingController _amountCtrl = TextEditingController();
  final TextEditingController _noteCtrl = TextEditingController();

  String _type = 'expense';
  String _categoryId = '';
  DateTime _date = DateTime.now();

  @override
  void dispose() {
    _amountCtrl.dispose();
    _noteCtrl.dispose();
    super.dispose();
  }

  int? get _amount => int.tryParse(_amountCtrl.text);

  bool get _canSave => (_amount ?? 0) > 0 && _categoryId.isNotEmpty;

  void _setType(String type) {
    setState(() {
      _type = type;
      _categoryId = '';
    });
  }

  Future<void> _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _date,
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
    );
    if (picked != null && mounted) {
      setState(() => _date = picked);
    }
  }

  void _submit() {
    if (!_canSave) return;
    final day = DateTime(_date.year, _date.month, _date.day);
    final t = FinanceTransaction(
      id: newId(),
      amount: _amount!,
      categoryId: _categoryId,
      type: _type,
      date: day.toUtc().toIso8601String(),
      note: _noteCtrl.text,
    );
    context.read<FinanceStore>().addTransaction(t);
    context.showToast('Transaksi berhasil disimpan');
    goTab(context, 0);
  }

  Future<void> _openCategorySheet() async {
    final cat = await showModalBottomSheet<TxCategory>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      barrierColor: Colors.black54,
      builder: (_) => NewCategorySheet(type: _type),
    );
    if (cat == null || !mounted) return;
    context.read<FinanceStore>().addCategory(cat);
    setState(() => _categoryId = cat.id);
    context.showToast('Kategori berhasil dibuat');
  }

  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    final categories = context
        .watch<FinanceStore>()
        .state
        .categories
        .where((c) => c.type == _type)
        .toList();

    return Scaffold(
      backgroundColor: p.bg,
      body: SafeArea(
        child: Column(
          children: [
            // Header
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(color: p.card, boxShadow: shadowSm),
              child: Row(
                children: [
                  GestureDetector(
                    behavior: HitTestBehavior.opaque,
                    onTap: () => Navigator.of(context).maybePop(),
                    child: Padding(
                      padding: const EdgeInsets.all(8),
                      child: Icon(Icons.chevron_left, size: 24, color: p.text),
                    ),
                  ),
                  const SizedBox(width: 16),
                  Text(
                    'Tambah Transaksi',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w700,
                      color: p.text,
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    _typeToggle(p),
                    const SizedBox(height: 24),
                    _amountField(p),
                    const SizedBox(height: 24),
                    _categoryGrid(p, categories),
                    const SizedBox(height: 24),
                    _dateNoteCard(p),
                    const SizedBox(height: 32),
                    GradientButton(
                      label: 'Simpan Transaksi',
                      onPressed: _canSave ? _submit : null,
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _typeToggle(Pal p) {
    Widget seg(String type, String label, Color activeColor) {
      final active = _type == type;
      return Expanded(
        child: GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTap: () => _setType(type),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 150),
            padding: const EdgeInsets.symmetric(vertical: 8),
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: active ? p.segActive : Colors.transparent,
              borderRadius: BorderRadius.circular(8),
              boxShadow: active ? shadowSm : null,
            ),
            child: Text(
              label,
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w500,
                color: active ? activeColor : p.muted,
              ),
            ),
          ),
        ),
      );
    }

    return Container(
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: p.segBg,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          seg('expense', 'Pengeluaran', AppColors.red500),
          seg('income', 'Pemasukan', AppColors.emerald500),
        ],
      ),
    );
  }

  Widget _label(String text) => Text(
        text.toUpperCase(),
        style: const TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.w700,
          letterSpacing: 0.6,
          color: AppColors.gray500,
        ),
      );

  Widget _amountField(Pal p) {
    UnderlineInputBorder line(Color c, double w) =>
        UnderlineInputBorder(borderSide: BorderSide(color: c, width: w));

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        _label('Jumlah (Rp)'),
        const SizedBox(height: 8),
        TextField(
          controller: _amountCtrl,
          autofocus: true,
          keyboardType: TextInputType.number,
          inputFormatters: [
            FilteringTextInputFormatter.digitsOnly,
            LengthLimitingTextInputFormatter(12),
          ],
          onChanged: (_) => setState(() {}),
          style: TextStyle(
            fontSize: 30,
            fontWeight: FontWeight.w700,
            color: p.text,
          ),
          decoration: InputDecoration(
            isDense: true,
            hintText: '0',
            hintStyle: const TextStyle(color: AppColors.gray300),
            contentPadding: const EdgeInsets.symmetric(vertical: 8),
            border: line(p.border2, 2),
            enabledBorder: line(p.border2, 2),
            focusedBorder: line(AppColors.primary, 2),
          ),
        ),
      ],
    );
  }

  Widget _categoryGrid(Pal p, List<TxCategory> categories) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        _label('Kategori'),
        const SizedBox(height: 8),
        LayoutBuilder(
          builder: (context, constraints) {
            final cell = (constraints.maxWidth - 3 * 12) / 4;
            return Wrap(
              spacing: 12,
              runSpacing: 12,
              children: [
                for (final cat in categories) _categoryCell(p, cat, cell),
                _addCategoryCell(p, cell),
              ],
            );
          },
        ),
      ],
    );
  }

  Widget _categoryCell(Pal p, TxCategory cat, double width) {
    final selected = _categoryId == cat.id;
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () => setState(() => _categoryId = cat.id),
      child: Container(
        width: width,
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: selected
              ? tint(AppColors.primary, p.dark ? .2 : .05)
              : p.card,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: selected ? AppColors.primary : Colors.transparent,
            width: 2,
          ),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            IconCircle(
              color: cat.colorValue,
              icon: categoryIcon(cat.icon),
              shadow: true,
            ),
            const SizedBox(height: 4),
            Text(
              cat.name,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 10,
                fontWeight: FontWeight.w500,
                color: p.text2,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _addCategoryCell(Pal p, double width) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: _openCategorySheet,
      child: CustomPaint(
        painter: DashedRRectPainter(
          color: p.dark ? AppColors.slate700 : AppColors.gray300,
        ),
        child: Container(
          width: width,
          padding: const EdgeInsets.all(10),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: p.chip,
                  shape: BoxShape.circle,
                ),
                child: const Icon(Icons.add, size: 20, color: AppColors.gray400),
              ),
              const SizedBox(height: 4),
              const Text(
                'Tambah',
                style: TextStyle(
                  fontSize: 10,
                  fontWeight: FontWeight.w500,
                  color: AppColors.gray400,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _dateNoteCard(Pal p) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: cardDecoration(p, radius: 12, border: false),
      child: Column(
        children: [
          GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTap: _pickDate,
            child: Container(
              padding: const EdgeInsets.only(bottom: 12),
              decoration: BoxDecoration(
                border: Border(bottom: BorderSide(color: p.border)),
              ),
              child: Row(
                children: [
                  const Icon(Icons.calendar_today_outlined, size: 20, color: AppColors.gray400),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      fmtDateInput(_date),
                      style: TextStyle(fontSize: 16, color: p.text),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              const Icon(Icons.description_outlined, size: 20, color: AppColors.gray400),
              const SizedBox(width: 12),
              Expanded(
                child: TextField(
                  controller: _noteCtrl,
                  style: TextStyle(fontSize: 16, color: p.text),
                  textCapitalization: TextCapitalization.sentences,
                  decoration: InputDecoration(
                    isDense: true,
                    border: InputBorder.none,
                    contentPadding: EdgeInsets.zero,
                    hintText: 'Catatan (Opsional)',
                    hintStyle: TextStyle(color: p.faint),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

/// Modal "Buat Kategori Baru".
class NewCategorySheet extends StatefulWidget {
  const NewCategorySheet({super.key, required this.type});

  final String type;

  @override
  State<NewCategorySheet> createState() => _NewCategorySheetState();
}

class _NewCategorySheetState extends State<NewCategorySheet> {
  final TextEditingController _nameCtrl = TextEditingController();
  String _icon = 'Circle';

  @override
  void dispose() {
    _nameCtrl.dispose();
    super.dispose();
  }

  void _save() {
    final name = _nameCtrl.text.trim();
    if (name.isEmpty) return;
    Navigator.of(context).pop(
      TxCategory(
        id: newId(),
        name: name,
        icon: _icon,
        color: randomHexColor(),
        type: widget.type,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);

    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.viewInsetsOf(context).bottom),
      child: SafeArea(
        child: Container(
          margin: const EdgeInsets.all(16),
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: p.card,
            borderRadius: BorderRadius.circular(16),
            boxShadow: const [
              BoxShadow(color: Color(0x40000000), blurRadius: 50, offset: Offset(0, 25), spreadRadius: -12),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Buat Kategori Baru',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w700,
                      color: p.text,
                    ),
                  ),
                  GestureDetector(
                    behavior: HitTestBehavior.opaque,
                    onTap: () => Navigator.of(context).pop(),
                    child: const Icon(Icons.close, size: 24, color: AppColors.gray400),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              const Text(
                'Nama Kategori',
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                  color: AppColors.gray500,
                ),
              ),
              const SizedBox(height: 4),
              TextField(
                controller: _nameCtrl,
                autofocus: true,
                textCapitalization: TextCapitalization.sentences,
                style: TextStyle(color: p.text),
                onSubmitted: (_) => _save(),
                decoration: fieldDecoration(
                  p,
                  hint: 'Misal: Jajan, Pulsa',
                  fill: p.field2,
                ),
              ),
              const SizedBox(height: 16),
              const Text(
                'Pilih Ikon',
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                  color: AppColors.gray500,
                ),
              ),
              const SizedBox(height: 8),
              ConstrainedBox(
                constraints: const BoxConstraints(maxHeight: 160),
                child: SingleChildScrollView(
                  child: LayoutBuilder(
                    builder: (context, constraints) {
                      final cell = (constraints.maxWidth - 5 * 8) / 6;
                      return Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: [
                          for (final e in categoryIcons.entries)
                            GestureDetector(
                              behavior: HitTestBehavior.opaque,
                              onTap: () => setState(() => _icon = e.key),
                              child: Container(
                                width: cell,
                                height: cell,
                                decoration: BoxDecoration(
                                  color: _icon == e.key
                                      ? AppColors.primary
                                      : p.chip,
                                  borderRadius: BorderRadius.circular(8),
                                  boxShadow: _icon == e.key
                                      ? shadowGlow(AppColors.primary, .3, blur: 6, dy: 4, spread: -1)
                                      : null,
                                ),
                                child: Icon(
                                  e.value,
                                  size: 20,
                                  color: _icon == e.key
                                      ? Colors.white
                                      : p.muted,
                                ),
                              ),
                            ),
                        ],
                      );
                    },
                  ),
                ),
              ),
              const SizedBox(height: 16),
              PressScale(
                scale: 0.98,
                onTap: _save,
                child: Container(
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: AppColors.primary,
                    borderRadius: BorderRadius.circular(12),
                    boxShadow: shadowGlow(AppColors.primary, .3),
                  ),
                  child: const Text(
                    'Simpan Kategori',
                    style: TextStyle(
                      fontWeight: FontWeight.w700,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
