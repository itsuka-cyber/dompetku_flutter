import 'dart:math' as math;

import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../models.dart';
import '../state/finance_store.dart';
import '../state/toast.dart';
import '../theme.dart';
import '../utils.dart';
import '../widgets/app_shell.dart';
import '../widgets/common.dart';

class GoalsPage extends StatefulWidget {
  const GoalsPage({super.key});

  @override
  State<GoalsPage> createState() => _GoalsPageState();
}

class _GoalsPageState extends State<GoalsPage> {
  final TextEditingController _nameCtrl = TextEditingController();
  final TextEditingController _targetCtrl = TextEditingController();
  DateTime? _deadline;
  bool _isAdding = false;

  @override
  void dispose() {
    _nameCtrl.dispose();
    _targetCtrl.dispose();
    super.dispose();
  }

  Future<void> _pickDeadline() async {
    final now = DateTime.now();
    final picked = await showDatePicker(
      context: context,
      initialDate: _deadline ?? now,
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
    );
    if (picked != null && mounted) {
      setState(() => _deadline = picked);
    }
  }

  void _add() {
    final name = _nameCtrl.text.trim();
    final target = int.tryParse(_targetCtrl.text.trim());
    if (name.isEmpty || target == null || target <= 0 || _deadline == null) {
      context.showToast('Lengkapi nama, target, dan tanggal goal.', ToastType.error);
      return;
    }

    context.read<FinanceStore>().addGoal(
          SavingGoal(
            id: newId(),
            name: name,
            targetAmount: target,
            savedAmount: 0,
            deadline: isoDateOnly(_deadline!),
            color: randomHexColor(),
          ),
        );
    context.showToast('Target keuangan berhasil dibuat!');
    setState(() {
      _isAdding = false;
      _nameCtrl.clear();
      _targetCtrl.clear();
      _deadline = null;
    });
  }

  Future<void> _delete(String id) async {
    final ok = await confirmDialog(context, 'Hapus goal ini?',
        confirmLabel: 'Hapus', danger: true);
    if (!ok || !mounted) return;
    context.read<FinanceStore>().deleteGoal(id);
    context.showToast('Target dihapus.', ToastType.info);
  }

  void _addMoney(SavingGoal g, int amount, String label) {
    context
        .read<FinanceStore>()
        .updateGoal(g.copyWith(savedAmount: g.savedAmount + amount));
    context.showToast('Ditambahkan $label');
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<FinanceStore>().state;
    final p = Pal.of(context);

    return AppShell(
      tab: 3,
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Target Keuangan',
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.w700,
                    color: p.text,
                  ),
                ),
                GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTap: () => setState(() => _isAdding = !_isAdding),
                  child: Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      color: AppColors.primary,
                      shape: BoxShape.circle,
                      boxShadow: shadowGlow(AppColors.primary, .3),
                    ),
                    child: const Icon(Icons.add, size: 24, color: Colors.white),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 24),
            if (_isAdding) ...[
              FadeSlideIn(dy: -16, child: _form(p)),
              const SizedBox(height: 24),
            ],
            for (final g in s.goals)
              Padding(
                padding: const EdgeInsets.only(bottom: 16),
                child: _goalCard(p, g),
              ),
          ],
        ),
      ),
    );
  }

  Widget _form(Pal p) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: cardDecoration(p, radius: 12, border: false),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(
            'Buat Goal Baru',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w600,
              color: p.text,
            ),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _nameCtrl,
            textCapitalization: TextCapitalization.sentences,
            style: TextStyle(color: p.text),
            decoration: fieldDecoration(p, hint: 'Nama Goal (mis: Beli HP)'),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _targetCtrl,
            keyboardType: TextInputType.number,
            inputFormatters: [
              FilteringTextInputFormatter.digitsOnly,
              LengthLimitingTextInputFormatter(12),
            ],
            style: TextStyle(color: p.text),
            decoration: fieldDecoration(p, hint: 'Target (Rp)'),
          ),
          const SizedBox(height: 12),
          GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTap: _pickDeadline,
            child: Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: p.field2,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: p.border2),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      _deadline == null ? 'dd/mm/yyyy' : fmtDateInput(_deadline!),
                      style: TextStyle(
                        fontSize: 16,
                        color: _deadline == null ? p.faint : p.text,
                      ),
                    ),
                  ),
                  const Icon(Icons.calendar_today_outlined, size: 18, color: AppColors.gray400),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          PressScale(
            scale: 0.98,
            onTap: _add,
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 12),
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: AppColors.primary,
                borderRadius: BorderRadius.circular(8),
                boxShadow: shadowGlow(AppColors.primary, .3),
              ),
              child: const Text(
                'Simpan Goal',
                style: TextStyle(
                  fontWeight: FontWeight.w700,
                  color: Colors.white,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _goalCard(Pal p, SavingGoal g) {
    final percent = math.min(100, math.max(0, (g.ratio * 100).round()));
    final remaining = g.targetAmount - g.savedAmount;
    final hasValues = g.savedAmount > 0 || remaining > 0;

    final sections = hasValues
        ? <PieChartSectionData>[
            PieChartSectionData(
              value: math.max(0.0, g.savedAmount.toDouble()),
              color: g.colorValue,
              radius: 10,
              showTitle: false,
            ),
            PieChartSectionData(
              value: math.max(0.0, remaining.toDouble()),
              color: AppColors.slate200,
              radius: 10,
              showTitle: false,
            ),
          ]
        : <PieChartSectionData>[
            PieChartSectionData(
              value: 1,
              color: AppColors.slate200,
              radius: 10,
              showTitle: false,
            ),
          ];

    final deadline = DateTime.tryParse(g.deadline);

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: cardDecoration(p),
      child: Row(
        children: [
          SizedBox(
            width: 80,
            height: 80,
            child: Stack(
              alignment: Alignment.center,
              children: [
                PieChart(
                  PieChartData(
                    startDegreeOffset: 270,
                    sectionsSpace: 0,
                    centerSpaceRadius: 25,
                    pieTouchData: PieTouchData(enabled: false),
                    sections: sections,
                  ),
                ),
                Text(
                  '$percent%',
                  style: TextStyle(
                    fontSize: 10,
                    fontWeight: FontWeight.w700,
                    color: p.text,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: Text(
                        g.name,
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w700,
                          color: p.dark ? Colors.white : AppColors.gray800,
                        ),
                      ),
                    ),
                    GestureDetector(
                      behavior: HitTestBehavior.opaque,
                      onTap: () => _delete(g.id),
                      child: const Padding(
                        padding: EdgeInsets.only(left: 8, bottom: 8),
                        child: Icon(Icons.delete_outline, size: 16, color: AppColors.gray300),
                      ),
                    ),
                  ],
                ),
                Text(
                  'Target: ${formatRupiah(g.targetAmount)}',
                  style: TextStyle(fontSize: 12, color: p.muted),
                ),
                const SizedBox(height: 8),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Flexible(
                      child: Text(
                        'Terkumpul: ${formatRupiah(g.savedAmount)}',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontSize: 10, color: AppColors.gray400),
                      ),
                    ),
                    const SizedBox(width: 4),
                    Text(
                      deadline == null ? '-' : fmtDateShort(deadline),
                      style: const TextStyle(fontSize: 10, color: AppColors.gray400),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    _quickAdd(p, '+ Rp 50rb', () => _addMoney(g, 50000, 'Rp 50.000')),
                    const SizedBox(width: 8),
                    _quickAdd(p, '+ Rp 100rb', () => _addMoney(g, 100000, 'Rp 100.000')),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _quickAdd(Pal p, String label, VoidCallback onTap) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        decoration: BoxDecoration(
          color: p.chip,
          borderRadius: BorderRadius.circular(4),
        ),
        child: Text(
          label,
          style: const TextStyle(
            fontSize: 10,
            fontWeight: FontWeight.w500,
            color: AppColors.primary,
          ),
        ),
      ),
    );
  }
}
