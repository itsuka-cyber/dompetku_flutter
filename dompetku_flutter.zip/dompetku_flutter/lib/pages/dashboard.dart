import 'dart:math' as math;

import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../models.dart';
import '../nav.dart';
import '../state/finance_store.dart';
import '../state/toast.dart';
import '../theme.dart';
import '../utils.dart';
import '../widgets/app_shell.dart';
import '../widgets/common.dart';
import '../widgets/icons.dart';

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  final TextEditingController _transferCtrl = TextEditingController();
  bool _showTransfer = false;

  @override
  void dispose() {
    _transferCtrl.dispose();
    super.dispose();
  }

  void _handleTransfer() {
    final amount = int.tryParse(_transferCtrl.text.trim());
    if (amount == null || amount == 0) return;
    context.read<FinanceStore>().transferToSavings(amount);
    context.showToast(amount > 0 ? 'Berhasil ditabung!' : 'Penarikan berhasil!');
    setState(() {
      _transferCtrl.clear();
      _showTransfer = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<FinanceStore>().state;
    final p = Pal.of(context);
    final now = DateTime.now();

    bool thisMonth(FinanceTransaction t) {
      final d = t.dateTime;
      return d.month == now.month && d.year == now.year;
    }

    final monthlyExpenses = s.transactions
        .where((t) => t.type == 'expense' && thisMonth(t))
        .fold<int>(0, (a, t) => a + t.amount);

    final budgetProgress = s.budget.limit > 0
        ? math.min(monthlyExpenses / s.budget.limit * 100, 100.0)
        : 0.0;

    final pieData = <CategorySlice>[
      for (final cat in s.categories.where((c) => c.type == 'expense'))
        CategorySlice(
          cat.name,
          s.transactions
              .where((t) => t.categoryId == cat.id && thisMonth(t))
              .fold<int>(0, (a, t) => a + t.amount),
          cat.colorValue,
        ),
    ].where((d) => d.value > 0).toList();

    final userName = s.userName.isEmpty ? 'Pengguna' : s.userName;

    return AppShell(
      tab: 0,
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            _header(p, userName),
            const SizedBox(height: 24),
            _balanceCard(s),
            if (_showTransfer) ...[
              const SizedBox(height: 24),
              FadeSlideIn(dy: -16, child: _transferForm(p)),
            ],
            const SizedBox(height: 24),
            _budgetCard(p, s, monthlyExpenses, budgetProgress),
            const SizedBox(height: 24),
            SizedBox(
              height: 168,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Expanded(child: _expenseCard(p, pieData)),
                  const SizedBox(width: 16),
                  Expanded(child: _goalsCard(p, s)),
                ],
              ),
            ),
            const SizedBox(height: 24),
            _recent(p, s),
          ],
        ),
      ),
    );
  }

  // --- Header ----------------------------------------------------------------

  Widget _header(Pal p, String userName) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Halo,', style: TextStyle(fontSize: 14, color: p.muted)),
              Text(
                capitalizeWords(userName),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  fontSize: 24,
                  height: 1.33,
                  fontWeight: FontWeight.w700,
                  color: p.text,
                ),
              ),
            ],
          ),
        ),
        const SizedBox(width: 12),
        Container(
          width: 40,
          height: 40,
          alignment: Alignment.center,
          decoration: const BoxDecoration(
            gradient: primaryGradientH,
            shape: BoxShape.circle,
          ),
          child: Text(
            String.fromCharCode(userName.runes.first).toUpperCase(),
            style: const TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w700,
              color: Colors.white,
            ),
          ),
        ),
      ],
    );
  }

  // --- Kartu saldo -------------------------------------------------------------

  Widget _balanceCard(AppState s) {
    return Container(
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [AppColors.indigo600, AppColors.violet700],
        ),
        borderRadius: BorderRadius.circular(16),
        boxShadow: shadowGlow(AppColors.primary, .2, blur: 25, dy: 20, spread: -5),
      ),
      child: Stack(
        children: [
          Positioned(
            top: -32,
            right: -32,
            child: Container(
              width: 128,
              height: 128,
              decoration: BoxDecoration(
                color: tint(Colors.white, .05),
                shape: BoxShape.circle,
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Saldo Utama',
                  style: TextStyle(fontSize: 14, color: AppColors.indigo100),
                ),
                const SizedBox(height: 4),
                Text(
                  formatRupiah(s.balance),
                  style: const TextStyle(
                    fontSize: 30,
                    height: 1.2,
                    fontWeight: FontWeight.w700,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(height: 24),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'Tabungan',
                          style: TextStyle(
                            fontSize: 12,
                            color: AppColors.indigo100,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Row(
                          children: [
                            const Icon(
                              Icons.savings_outlined,
                              size: 16,
                              color: Colors.white,
                            ),
                            const SizedBox(width: 8),
                            Text(
                              formatRupiah(s.savings),
                              style: const TextStyle(
                                fontWeight: FontWeight.w600,
                                color: Colors.white,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                    GestureDetector(
                      behavior: HitTestBehavior.opaque,
                      onTap: () => setState(() => _showTransfer = !_showTransfer),
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 12,
                          vertical: 6,
                        ),
                        decoration: BoxDecoration(
                          color: tint(Colors.white, .2),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(
                          _showTransfer ? 'Batal' : 'Tabung',
                          style: const TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w500,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _transferForm(Pal p) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: p.card2,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: p.dark ? AppColors.slate700 : AppColors.indigo100),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Transfer ke Tabungan (atau (-) untuk tarik)',
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w500,
              color: p.text2,
            ),
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _transferCtrl,
                  keyboardType: const TextInputType.numberWithOptions(signed: true),
                  inputFormatters: [
                    FilteringTextInputFormatter.allow(RegExp(r'[0-9-]')),
                    LengthLimitingTextInputFormatter(12),
                  ],
                  style: TextStyle(color: p.text),
                  onSubmitted: (_) => _handleTransfer(),
                  decoration: fieldDecoration(
                    p,
                    hint: 'Contoh: 50000',
                    fill: p.field,
                    padding: const EdgeInsets.symmetric(
                      horizontal: 16,
                      vertical: 10,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              PressScale(
                onTap: _handleTransfer,
                child: Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 10,
                  ),
                  decoration: BoxDecoration(
                    color: AppColors.primary,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Text(
                    'Proses',
                    style: TextStyle(
                      fontWeight: FontWeight.w500,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // --- Budget ------------------------------------------------------------------

  Widget _budgetCard(Pal p, AppState s, int monthlyExpenses, double progress) {
    final barColor = progress > 90
        ? AppColors.red500
        : (progress > 75 ? AppColors.orange500 : AppColors.primary);

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: cardDecoration(p),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Budget Bulanan',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  color: p.text,
                ),
              ),
              Text(
                s.budget.enabled
                    ? '${progress.round()}% terpakai'
                    : 'Tidak Aktif',
                style: const TextStyle(fontSize: 12, color: AppColors.gray500),
              ),
            ],
          ),
          const SizedBox(height: 12),
          if (s.budget.enabled) ...[
            Container(
              height: 12,
              decoration: BoxDecoration(
                color: p.track,
                borderRadius: BorderRadius.circular(6),
              ),
              clipBehavior: Clip.antiAlias,
              alignment: Alignment.centerLeft,
              child: TweenAnimationBuilder<double>(
                tween: Tween<double>(begin: 0, end: progress / 100),
                duration: const Duration(milliseconds: 1000),
                curve: Curves.easeOut,
                builder: (context, v, _) => FractionallySizedBox(
                  widthFactor: clamp01(v),
                  child: Container(
                    decoration: BoxDecoration(
                      color: barColor,
                      borderRadius: BorderRadius.circular(6),
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Terpakai: ${formatRupiah(monthlyExpenses)}',
                  style: TextStyle(fontSize: 12, color: p.muted),
                ),
                Text(
                  'Limit: ${formatRupiah(s.budget.limit)}',
                  style: TextStyle(fontSize: 12, color: p.muted),
                ),
              ],
            ),
          ] else
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Flexible(
                  child: Text.rich(
                    TextSpan(
                      text: 'Total Pengeluaran: ',
                      style: TextStyle(fontSize: 12, color: p.muted),
                      children: [
                        TextSpan(
                          text: formatRupiah(monthlyExpenses),
                          style: TextStyle(
                            fontWeight: FontWeight.w600,
                            color: p.dark ? Colors.white : AppColors.gray800,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTap: () => goTab(context, 4),
                  child: const Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.settings_outlined, size: 12, color: AppColors.primary),
                      SizedBox(width: 4),
                      Text(
                        'Atur Budget',
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w500,
                          color: AppColors.primary,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
        ],
      ),
    );
  }

  // --- Kartu kecil: pengeluaran & goal ------------------------------------------

  Widget _expenseCard(Pal p, List<CategorySlice> pieData) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: cardDecoration(p),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Pengeluaran',
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: p.text,
                ),
              ),
              GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: () => goTab(context, 1),
                child: const Icon(Icons.arrow_forward, size: 16, color: AppColors.primary),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Expanded(
            child: pieData.isNotEmpty
                ? PieChart(
                    PieChartData(
                      sectionsSpace: 3,
                      centerSpaceRadius: 25,
                      pieTouchData: PieTouchData(enabled: false),
                      sections: [
                        for (final d in pieData)
                          PieChartSectionData(
                            value: d.value.toDouble(),
                            color: d.color,
                            radius: 15,
                            showTitle: false,
                          ),
                      ],
                    ),
                  )
                : const Center(
                    child: Text(
                      'Belum ada data',
                      style: TextStyle(fontSize: 12, color: AppColors.gray400),
                    ),
                  ),
          ),
        ],
      ),
    );
  }

  Widget _goalsCard(Pal p, AppState s) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: cardDecoration(p),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Goal Aktif',
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: p.text,
                ),
              ),
              GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: () => goTab(context, 3),
                child: const Icon(Icons.add, size: 16, color: AppColors.primary),
              ),
            ],
          ),
          const SizedBox(height: 8),
          if (s.goals.isEmpty)
            const Text(
              'Belum ada goal.',
              style: TextStyle(fontSize: 12, color: AppColors.gray400),
            )
          else
            for (final g in s.goals.take(2))
              Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Expanded(
                          child: Text(
                            g.name,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(fontSize: 12, color: p.text2),
                          ),
                        ),
                        const SizedBox(width: 4),
                        Text(
                          '${(g.ratio * 100).round()}%',
                          style: TextStyle(fontSize: 12, color: p.text2),
                        ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Container(
                      height: 6,
                      decoration: BoxDecoration(
                        color: p.track,
                        borderRadius: BorderRadius.circular(3),
                      ),
                      alignment: Alignment.centerLeft,
                      child: FractionallySizedBox(
                        widthFactor: clamp01(g.ratio),
                        child: Container(
                          decoration: BoxDecoration(
                            color: g.colorValue,
                            borderRadius: BorderRadius.circular(3),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
        ],
      ),
    );
  }

  // --- Transaksi terakhir ----------------------------------------------------------

  Widget _recent(Pal p, AppState s) {
    final latest = s.transactions.take(5).toList();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'Transaksi Terakhir',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w700,
                color: p.text,
              ),
            ),
            GestureDetector(
              behavior: HitTestBehavior.opaque,
              onTap: () => openTransactions(context),
              child: const Text(
                'Lihat Semua',
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                  color: AppColors.primary,
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),
        for (var i = 0; i < latest.length; i++)
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: FadeSlideIn(
              delay: Duration(milliseconds: i * 100),
              child: _recentTile(p, s, latest[i]),
            ),
          ),
        if (latest.isEmpty)
          const Padding(
            padding: EdgeInsets.symmetric(vertical: 40),
            child: Center(
              child: Text(
                'Belum ada transaksi. Yuk mulai catat!',
                style: TextStyle(color: AppColors.gray400),
              ),
            ),
          ),
      ],
    );
  }

  Widget _recentTile(Pal p, AppState s, FinanceTransaction t) {
    final cat = findCategory(s.categories, t.categoryId);
    final income = t.type == 'income';

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: cardDecoration(p, radius: 12),
      child: Row(
        children: [
          IconCircle(
            color: cat?.colorValue ?? const Color(0xFF94A3B8),
            icon: categoryIcon(cat?.icon ?? 'Circle'),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  t.note.isNotEmpty ? t.note : (cat?.name ?? 'Transaksi'),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: p.text,
                  ),
                ),
                Text(
                  fmtDateShort(t.dateTime),
                  style: TextStyle(fontSize: 12, color: p.muted),
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          Text(
            '${income ? '+' : '-'}${formatRupiah(t.amount)}',
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w700,
              color: income ? AppColors.emerald500 : AppColors.red500,
            ),
          ),
        ],
      ),
    );
  }
}
