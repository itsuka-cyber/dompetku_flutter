import 'dart:math' as math;
import 'dart:ui' show ImageFilter;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../state/finance_store.dart';
import '../theme.dart';
import '../widgets/common.dart';

class _Slide {
  const _Slide(this.icon, this.title, this.desc);

  final IconData icon;
  final String title;
  final String desc;
}

class OnboardingPage extends StatefulWidget {
  const OnboardingPage({super.key});

  @override
  State<OnboardingPage> createState() => _OnboardingPageState();
}

class _OnboardingPageState extends State<OnboardingPage> {
  static const List<_Slide> _slides = [
    _Slide(
      Icons.account_balance_wallet_outlined,
      'Kelola Keuangan',
      'Catat pemasukan dan pengeluaranmu dengan mudah dan cepat, tanpa internet.',
    ),
    _Slide(
      Icons.pie_chart_outline,
      'Analisis Visual',
      'Pantau kemana uangmu pergi dengan grafik interaktif yang menarik.',
    ),
    _Slide(
      Icons.verified_user_outlined,
      'Data Aman',
      'Semua data tersimpan di HP kamu sendiri. Aman dan privasi terjaga.',
    ),
  ];

  final TextEditingController _nameCtrl = TextEditingController();
  int _step = 0;

  bool get _isLast => _step == _slides.length - 1;

  @override
  void dispose() {
    _nameCtrl.dispose();
    super.dispose();
  }

  void _next() {
    if (_step < _slides.length - 1) {
      setState(() => _step++);
    }
  }

  Future<void> _finish() async {
    final name = _nameCtrl.text.trim();
    if (name.isEmpty) {
      await alertDialog(context, 'Masukkan namamu dulu ya!');
      return;
    }
    // RootGate otomatis berpindah ke Dashboard setelah onboarding selesai.
    context.read<FinanceStore>().completeOnboarding(name);
  }

  Widget _blob(Color color) => ImageFiltered(
        imageFilter: ImageFilter.blur(sigmaX: 32, sigmaY: 32),
        child: Container(
          width: 256,
          height: 256,
          decoration: BoxDecoration(color: color, shape: BoxShape.circle),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    final slide = _slides[_step];

    return Scaffold(
      backgroundColor: p.dark ? AppColors.slate950 : Colors.white,
      body: Stack(
        clipBehavior: Clip.hardEdge,
        children: [
          // Latar blob blur
          Positioned(
            top: -128,
            left: -128,
            child: _blob(
              p.dark ? tint(AppColors.indigo900, .3) : AppColors.indigo200,
            ),
          ),
          Positioned(
            bottom: -128,
            right: -128,
            child: _blob(
              p.dark ? tint(AppColors.teal900, .3) : AppColors.teal200,
            ),
          ),
          SafeArea(
            child: Center(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(32),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Center(
                      child: Transform.rotate(
                        angle: 3 * math.pi / 180,
                        child: Container(
                          width: 96,
                          height: 96,
                          decoration: BoxDecoration(
                            gradient: primaryGradient,
                            borderRadius: BorderRadius.circular(24),
                            boxShadow: shadowGlow(
                              AppColors.primary,
                              .3,
                              blur: 50,
                              dy: 25,
                              spread: -12,
                            ),
                          ),
                          child: Icon(slide.icon, size: 48, color: Colors.white),
                        ),
                      ),
                    ),
                    const SizedBox(height: 48),
                    Text(
                      slide.title,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 30,
                        fontWeight: FontWeight.w700,
                        color: p.text,
                      ),
                    ),
                    const SizedBox(height: 16),
                    Text(
                      slide.desc,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 16,
                        height: 1.625,
                        color: p.muted,
                      ),
                    ),
                    const SizedBox(height: 32),
                    if (_isLast)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 32),
                        child: FadeSlideIn(
                          dy: 16,
                          child: TextField(
                            controller: _nameCtrl,
                            textAlign: TextAlign.center,
                            textCapitalization: TextCapitalization.words,
                            style: TextStyle(fontSize: 18, color: p.text),
                            onSubmitted: (_) => _finish(),
                            decoration: fieldDecoration(
                              p,
                              hint: 'Siapa namamu?',
                              fill: p.field,
                              radius: 12,
                              padding: const EdgeInsets.symmetric(
                                horizontal: 16,
                                vertical: 12,
                              ),
                            ),
                          ),
                        ),
                      ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        for (var i = 0; i < _slides.length; i++)
                          AnimatedContainer(
                            duration: const Duration(milliseconds: 300),
                            margin: const EdgeInsets.symmetric(horizontal: 4),
                            height: 8,
                            width: i == _step ? 32 : 8,
                            decoration: BoxDecoration(
                              color: i == _step
                                  ? AppColors.primary
                                  : (p.dark
                                      ? AppColors.slate800
                                      : AppColors.gray200),
                              borderRadius: BorderRadius.circular(4),
                            ),
                          ),
                      ],
                    ),
                    const SizedBox(height: 48),
                    PressScale(
                      onTap: _isLast ? _finish : _next,
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          color: p.strongBg,
                          borderRadius: BorderRadius.circular(12),
                          boxShadow: const [
                            BoxShadow(
                              color: Color(0x1A000000),
                              blurRadius: 15,
                              spreadRadius: -3,
                              offset: Offset(0, 10),
                            ),
                          ],
                        ),
                        child: Text(
                          _isLast ? 'Mulai Sekarang' : 'Lanjut',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w700,
                            color: p.strongFg,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
