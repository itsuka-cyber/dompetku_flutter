import 'dart:convert';
import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';

import '../main.dart' show RootGate;
import '../models.dart';
import '../nav.dart';
import '../state/finance_store.dart';
import '../state/toast.dart';
import '../theme.dart';
import '../utils.dart';
import '../widgets/app_shell.dart';
import '../widgets/common.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  // --- Backup (format sama dengan versi web: {data: base64(encodeURIComponent(json)), v: 1})

  Future<void> _backup() async {
    try {
      final state = context.read<FinanceStore>().state;
      final jsonStr = jsonEncode(state.toJson());
      final encoded = base64Encode(utf8.encode(Uri.encodeComponent(jsonStr)));
      final out = jsonEncode({'data': encoded, 'v': 1});

      final dir = await getTemporaryDirectory();
      final name = 'dompetku_backup_${isoDateOnly(DateTime.now())}.json';
      final file = File('${dir.path}/$name');
      await file.writeAsString(out);

      await Share.shareXFiles(
        [XFile(file.path, mimeType: 'application/json')],
        subject: 'Backup DompetKu',
      );
      if (!mounted) return;
      context.showToast('Backup berhasil dibuat!');
    } catch (e) {
      if (!mounted) return;
      context.showToast('Gagal membuat backup.', ToastType.error);
    }
  }

  Future<void> _restore() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: const ['json'],
      withData: true,
    );
    if (result == null || result.files.isEmpty) return;
    if (!mounted) return;

    try {
      final picked = result.files.single;
      final bytes = picked.bytes ?? await File(picked.path!).readAsBytes();
      final json = jsonDecode(utf8.decode(bytes));

      if (json is Map && json['data'] is String) {
        final decoded = Uri.decodeComponent(
          utf8.decode(base64Decode(json['data'] as String)),
        );
        final parsed = jsonDecode(decoded);
        if (parsed is! Map) throw const FormatException('bukan objek');
        final newState = AppState.fromJson(Map<String, dynamic>.from(parsed));

        if (!mounted) return;
        final ok = await confirmDialog(
          context,
          'Data saat ini akan ditimpa. Lanjutkan?',
        );
        if (!ok || !mounted) return;
        context.read<FinanceStore>().restoreData(newState);
        context.showToast('Data berhasil dipulihkan!');
      } else {
        context.showToast('Format file tidak valid.', ToastType.error);
      }
    } catch (e) {
      if (!mounted) return;
      context.showToast('Gagal membaca file backup.', ToastType.error);
    }
  }

  Future<void> _reset() async {
    final ok = await confirmDialog(
      context,
      'Yakin ingin menghapus SEMUA data? Aksi ini tidak bisa dibatalkan.',
      confirmLabel: 'Hapus Semua',
      danger: true,
    );
    if (!ok || !mounted) return;

    final navigator = Navigator.of(context);
    final store = context.read<FinanceStore>();
    final toasts = context.read<ToastController>();

    await store.resetAll();
    toasts.show('Aplikasi direset.', ToastType.info);
    await Future<void>.delayed(const Duration(seconds: 1));
    navigator.pushAndRemoveUntil(
      instantRoute<void>(const RootGate()),
      (route) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    final store = context.watch<FinanceStore>();
    final s = store.state;
    final p = Pal.of(context);

    return AppShell(
      tab: 4,
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              'Pengaturan',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.w700,
                color: p.text,
              ),
            ),
            const SizedBox(height: 32),
            // key berubah saat budget berubah (mis. setelah restore) agar
            // isian ikut menyesuaikan, seperti useEffect di versi web.
            _BudgetCard(
              key: ValueKey('${s.budget.limit}-${s.budget.enabled}'),
              budget: s.budget,
            ),
            const SizedBox(height: 16),
            _darkModeCard(p, s.darkMode),
            const SizedBox(height: 16),
            Padding(
              padding: const EdgeInsets.only(top: 8, left: 4),
              child: Text(
                'DATA & KEAMANAN',
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 0.7,
                  color: p.faint,
                ),
              ),
            ),
            const SizedBox(height: 16),
            _actionCard(
              p,
              icon: Icons.download_outlined,
              iconBg: p.dark ? AppColors.slate800 : AppColors.emerald100,
              iconColor: AppColors.emerald600,
              title: 'Backup Data',
              subtitle: 'Simpan data ke file (.json)',
              onTap: _backup,
            ),
            const SizedBox(height: 16),
            _actionCard(
              p,
              icon: Icons.upload_outlined,
              iconBg: p.dark ? AppColors.slate800 : AppColors.blue100,
              iconColor: AppColors.blue600,
              title: 'Restore Data',
              subtitle: 'Pulihkan data dari file',
              onTap: _restore,
            ),
            const SizedBox(height: 16),
            _actionCard(
              p,
              icon: Icons.delete_outline,
              iconBg: p.dark ? AppColors.slate800 : AppColors.red100,
              iconColor: AppColors.red500,
              title: 'Reset Aplikasi',
              subtitle: 'Hapus semua data permanen',
              titleColor: p.dark ? const Color(0xFFF87171) : AppColors.red600,
              borderColor: p.dark ? tint(const Color(0xFF7F1D1D), .3) : AppColors.red100,
              onTap: _reset,
            ),
            const SizedBox(height: 40),
            const Icon(Icons.verified_user_outlined, size: 40, color: AppColors.gray300),
            const SizedBox(height: 8),
            const Text(
              'Aplikasi berjalan 100% Offline.',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 12, color: AppColors.gray400),
            ),
            const Text(
              'Data tersimpan aman di perangkat Anda.',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 12, color: AppColors.gray400),
            ),
            const SizedBox(height: 16),
            const Text(
              'Versi 1.0.0 • DompetKu',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 10, color: AppColors.gray300),
            ),
          ],
        ),
      ),
    );
  }

  Widget _iconBox(Color bg, Color fg, IconData icon) => Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: bg,
          borderRadius: BorderRadius.circular(8),
        ),
        child: Icon(icon, size: 20, color: fg),
      );

  Widget _darkModeCard(Pal p, bool darkMode) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: cardDecoration(p, radius: 12, border: false),
      child: Row(
        children: [
          _iconBox(
            p.dark ? AppColors.slate800 : AppColors.indigo100,
            p.dark ? const Color(0xFF818CF8) : AppColors.indigo600,
            darkMode ? Icons.dark_mode_outlined : Icons.light_mode_outlined,
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Mode Gelap',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                    color: p.text,
                  ),
                ),
                const Text(
                  'Ganti tampilan aplikasi',
                  style: TextStyle(fontSize: 12, color: AppColors.gray500),
                ),
              ],
            ),
          ),
          AppToggle(
            value: darkMode,
            onChanged: (_) => context.read<FinanceStore>().toggleDarkMode(),
          ),
        ],
      ),
    );
  }

  Widget _actionCard(
    Pal p, {
    required IconData icon,
    required Color iconBg,
    required Color iconColor,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
    Color? titleColor,
    Color? borderColor,
  }) {
    return PressScale(
      scale: 0.99,
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: p.card,
          borderRadius: BorderRadius.circular(12),
          border: borderColor != null ? Border.all(color: borderColor) : null,
          boxShadow: shadowSm,
        ),
        child: Row(
          children: [
            _iconBox(iconBg, iconColor, icon),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                      color: titleColor ?? p.text,
                    ),
                  ),
                  Text(
                    subtitle,
                    style: const TextStyle(fontSize: 12, color: AppColors.gray500),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Kartu "Limit Pengeluaran" dengan state lokal (draft) sebelum disimpan.
class _BudgetCard extends StatefulWidget {
  const _BudgetCard({super.key, required this.budget});

  final BudgetSetting budget;

  @override
  State<_BudgetCard> createState() => _BudgetCardState();
}

class _BudgetCardState extends State<_BudgetCard> {
  late final TextEditingController _limitCtrl =
      TextEditingController(text: widget.budget.limit.toString());
  late bool _enabled = widget.budget.enabled;

  @override
  void dispose() {
    _limitCtrl.dispose();
    super.dispose();
  }

  void _save() {
    context.read<FinanceStore>().setBudget(
          BudgetSetting(
            limit: int.tryParse(_limitCtrl.text.trim()) ?? 0,
            enabled: _enabled,
          ),
        );
    FocusScope.of(context).unfocus();
    context.showToast('Pengaturan budget disimpan!');
  }

  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: cardDecoration(p, radius: 12, border: false),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: p.dark ? AppColors.slate800 : AppColors.orange100,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Icon(
                  Icons.account_balance_wallet_outlined,
                  size: 20,
                  color: AppColors.orange600,
                ),
              ),
              const SizedBox(width: 12),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Limit Pengeluaran',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                      color: p.text,
                    ),
                  ),
                  const Text(
                    'Atur batas budget bulanan',
                    style: TextStyle(fontSize: 12, color: AppColors.gray500),
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: p.field2,
              borderRadius: BorderRadius.circular(8),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Aktifkan Budget',
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                    color: p.text2,
                  ),
                ),
                AppToggle(
                  value: _enabled,
                  onChanged: (v) => setState(() => _enabled = v),
                ),
              ],
            ),
          ),
          if (_enabled) ...[
            const SizedBox(height: 12),
            FadeSlideIn(
              dy: -8,
              duration: const Duration(milliseconds: 300),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Batas Maksimal (Rp)',
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w700,
                      color: AppColors.gray500,
                    ),
                  ),
                  const SizedBox(height: 4),
                  TextField(
                    controller: _limitCtrl,
                    keyboardType: TextInputType.number,
                    inputFormatters: [
                      FilteringTextInputFormatter.digitsOnly,
                      LengthLimitingTextInputFormatter(12),
                    ],
                    style: TextStyle(color: p.text),
                    decoration: fieldDecoration(p, fill: p.field2),
                  ),
                ],
              ),
            ),
          ],
          const SizedBox(height: 12),
          PressScale(
            scale: 0.98,
            onTap: _save,
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 10),
              decoration: BoxDecoration(
                color: p.strongBg,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.check, size: 16, color: p.strongFg),
                  const SizedBox(width: 8),
                  Text(
                    'Simpan Budget',
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                      color: p.strongFg,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
