import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models.dart';
import '../state/finance_store.dart';
import '../state/toast.dart';
import '../theme.dart';
import '../utils.dart';
import '../widgets/app_shell.dart';
import '../widgets/common.dart';
import '../widgets/icons.dart';

class TransactionsPage extends StatefulWidget {
  const TransactionsPage({super.key});

  @override
  State<TransactionsPage> createState() => _TransactionsPageState();
}

class _TransactionsPageState extends State<TransactionsPage> {
  static const double _revealWidth = 96;

  String _search = '';
  String _filter = 'all'; // all | income | expense

  // Swipe-to-delete
  String? _swipedId;
  double _dragDx = 0;

  Future<void> _delete(String id) async {
    final ok = await confirmDialog(
      context,
      'Apakah Anda yakin ingin menghapus transaksi ini? Saldo akan dikembalikan.',
      confirmLabel: 'Hapus',
      danger: true,
    );
    if (!ok || !mounted) return;
    context.read<FinanceStore>().deleteTransaction(id);
    context.showToast('Transaksi berhasil dihapus', ToastType.info);
    setState(() => _swipedId = null);
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<FinanceStore>().state;
    final p = Pal.of(context);
    final term = _search.toLowerCase();

    final filtered = s.transactions.where((t) {
      final cat = findCategory(s.categories, t.categoryId);
      final matchesSearch = t.note.toLowerCase().contains(term) ||
          (cat?.name ?? '').toLowerCase().contains(term);
      final matchesType = _filter == 'all' ? true : t.type == _filter;
      return matchesSearch && matchesType;
    }).toList();

    return AppShell(
      child: Column(
        children: [
          // Header (tetap di atas)
          Container(
            color: p.bg,
            padding: const EdgeInsets.fromLTRB(20, 20, 20, 8),
            child: Row(
              children: [
                GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTap: () => Navigator.of(context).maybePop(),
                  child: Padding(
                    padding: const EdgeInsets.all(8),
                    child: Icon(Icons.arrow_back, size: 24, color: p.text),
                  ),
                ),
                const SizedBox(width: 16),
                Text(
                  'Riwayat Transaksi',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w700,
                    color: p.text,
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
              children: [
                // Pencarian
                TextField(
                  onChanged: (v) => setState(() => _search = v),
                  style: TextStyle(color: p.text),
                  decoration: fieldDecoration(
                    p,
                    hint: 'Cari catatan atau kategori...',
                    fill: p.card,
                    radius: 12,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    prefixIcon: const Icon(Icons.search, size: 18, color: AppColors.gray400),
                  ),
                ),
                const SizedBox(height: 16),
                // Filter
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: [
                      _chip(p, 'all', 'Semua'),
                      const SizedBox(width: 8),
                      _chip(p, 'income', 'Pemasukan'),
                      const SizedBox(width: 8),
                      _chip(p, 'expense', 'Pengeluaran'),
                    ],
                  ),
                ),
                const SizedBox(height: 24),
                for (final t in filtered) _tile(p, s, t),
                if (filtered.isEmpty)
                  const Padding(
                    padding: EdgeInsets.symmetric(vertical: 80),
                    child: Center(
                      child: Text(
                        'Tidak ada transaksi ditemukan.',
                        style: TextStyle(color: AppColors.gray400),
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _chip(Pal p, String value, String label) {
    final active = _filter == value;
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () => setState(() => _filter = value),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          color: active ? AppColors.primary : p.card,
          borderRadius: BorderRadius.circular(8),
          border: active ? null : Border.all(color: p.border),
          boxShadow: active ? shadowGlow(AppColors.primary, .3) : null,
        ),
        child: Text(
          label,
          style: TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w500,
            color: active ? Colors.white : p.muted,
          ),
        ),
      ),
    );
  }

  Widget _tile(Pal p, AppState s, FinanceTransaction t) {
    final cat = findCategory(s.categories, t.categoryId);
    final isSwiped = _swipedId == t.id;
    final income = t.type == 'income';

    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(12),
        child: LayoutBuilder(
          builder: (context, constraints) {
            final width = constraints.maxWidth;
            return Stack(
              children: [
                // Tombol hapus di belakang (muncul saat digeser ke kiri)
                Positioned(
                  top: 0,
                  bottom: 0,
                  right: 0,
                  width: _revealWidth,
                  child: GestureDetector(
                    behavior: HitTestBehavior.opaque,
                    onTap: () => _delete(t.id),
                    child: Container(
                      color: AppColors.red500,
                      alignment: Alignment.center,
                      child: const Icon(Icons.delete_outline, size: 24, color: Colors.white),
                    ),
                  ),
                ),
                // Konten depan
                AnimatedSlide(
                  duration: const Duration(milliseconds: 300),
                  curve: Curves.easeOut,
                  offset: Offset(isSwiped ? -_revealWidth / width : 0, 0),
                  child: GestureDetector(
                    behavior: HitTestBehavior.opaque,
                    onTap: () {
                      if (isSwiped) setState(() => _swipedId = null);
                    },
                    onHorizontalDragStart: (_) {
                      _dragDx = 0;
                      if (_swipedId != null && _swipedId != t.id) {
                        setState(() => _swipedId = null);
                      }
                    },
                    onHorizontalDragUpdate: (d) => _dragDx += d.delta.dx,
                    onHorizontalDragEnd: (_) {
                      if (_dragDx < -50) {
                        setState(() => _swipedId = t.id);
                      } else if (_dragDx > 50 && _swipedId == t.id) {
                        setState(() => _swipedId = null);
                      }
                      _dragDx = 0;
                    },
                    child: Container(
                      padding: const EdgeInsets.all(16),
                      decoration: cardDecoration(p, radius: 12),
                      child: Row(
                        children: [
                          IconCircle(
                            color: cat?.colorValue ?? const Color(0xFFCBD5E1),
                            icon: categoryIcon(cat?.icon ?? 'Circle'),
                            iconSize: 18,
                            shadow: true,
                          ),
                          const SizedBox(width: 16),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  t.note.isNotEmpty
                                      ? t.note
                                      : (cat?.name ?? 'Tanpa Keterangan'),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.w600,
                                    color: p.text,
                                  ),
                                ),
                                Text(
                                  fmtDateFull(t.dateTime),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(fontSize: 12, color: p.muted),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(width: 8),
                          Text(
                            '${income ? '+' : '-'}${formatRupiah(t.amount)}',
                            maxLines: 1,
                            style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w700,
                              color: income
                                  ? AppColors.emerald500
                                  : AppColors.red500,
                            ),
                          ),
                          const SizedBox(width: 4),
                          AnimatedOpacity(
                            duration: const Duration(milliseconds: 150),
                            opacity: isSwiped ? 0 : 1,
                            child: GestureDetector(
                              behavior: HitTestBehavior.opaque,
                              onTap: isSwiped ? null : () => _delete(t.id),
                              child: const Padding(
                                padding: EdgeInsets.all(8),
                                child: Icon(
                                  Icons.delete_outline,
                                  size: 18,
                                  color: AppColors.gray300,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}
