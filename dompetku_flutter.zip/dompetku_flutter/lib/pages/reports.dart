import 'dart:math' as math;

import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models.dart';
import '../state/finance_store.dart';
import '../theme.dart';
import '../utils.dart';
import '../widgets/app_shell.dart';

class _MonthBar {
  const _MonthBar(this.name, this.income, this.expense);

  final String name;
  final int income;
  final int expense;
}

class ReportsPage extends StatefulWidget {
  const ReportsPage({super.key});

  @override
  State<ReportsPage> createState() => _ReportsPageState();
}

class _ReportsPageState extends State<ReportsPage> {
  bool _trend = false; // false = Bulan Ini, true = Tren 6 Bulan
  int _touched = -1;

  @override
  Widget build(BuildContext context) {
    final s = context.watch<FinanceStore>().state;
    final p = Pal.of(context);
    final now = DateTime.now();

    final monthly = s.transactions.where((t) {
      final d = t.dateTime;
      return d.month == now.month && d.year == now.year;
    }).toList();

    int sumOf(Iterable<FinanceTransaction> list, String type) => list
        .where((t) => t.type == type)
        .fold<int>(0, (a, t) => a + t.amount);

    final income = sumOf(monthly, 'income');
    final expense = sumOf(monthly, 'expense');
    final savingRate = income > 0 ? (income - expense) / income * 100 : 0.0;

    final List<CategorySlice> pieData = <CategorySlice>[
      for (final cat in s.categories.where((c) => c.type == 'expense'))
        CategorySlice(
          cat.name,
          monthly
              .where((t) => t.categoryId == cat.id)
              .fold<int>(0, (a, t) => a + t.amount),
          cat.colorValue,
        ),
    ].where((d) => d.value > 0).toList()
      ..sort((a, b) => b.value.compareTo(a.value));

    // 6 bulan terakhir
    final bars = <_MonthBar>[];
    for (var i = 5; i >= 0; i--) {
      final d = DateTime(now.year, now.month - i, 1);
      final inMonth = s.transactions.where((t) {
        final td = t.dateTime;
        return td.month == d.month && td.year == d.year;
      });
      bars.add(_MonthBar(
        fmtMonthShort(d),
        sumOf(inMonth, 'income'),
        sumOf(inMonth, 'expense'),
      ));
    }

    return AppShell(
      tab: 1,
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              'Laporan Keuangan',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.w700,
                color: p.text,
              ),
            ),
            const SizedBox(height: 24),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: _summary(p, 'Pemasukan', formatRupiah(income),
                      AppColors.emerald500, AppColors.emerald600),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _summary(p, 'Pengeluaran', formatRupiah(expense),
                      AppColors.red500, AppColors.red600),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _summary(p, 'Saving Rate',
                      '${savingRate.toStringAsFixed(1)}%',
                      AppColors.blue500, AppColors.blue600),
                ),
              ],
            ),
            const SizedBox(height: 24),
            _tabs(p),
            const SizedBox(height: 24),
            Container(
              constraints: const BoxConstraints(minHeight: 300),
              padding: const EdgeInsets.all(16),
              decoration: cardDecoration(p, border: false),
              child: _trend
                  ? _trendChart(p, bars)
                  : _monthChart(p, pieData, expense),
            ),
            if (!_trend && pieData.isNotEmpty) ...[
              const SizedBox(height: 24),
              Text(
                'Rincian Detail',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  color: p.text,
                ),
              ),
              const SizedBox(height: 12),
              for (final item in pieData)
                Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: _breakdownTile(p, item, expense),
                ),
            ],
          ],
        ),
      ),
    );
  }

  // --- Kartu ringkasan --------------------------------------------------------

  Widget _summary(Pal p, String label, String value, Color line, Color valueColor) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        boxShadow: shadowSm,
      ),
      clipBehavior: Clip.antiAlias,
      child: Container(
        color: p.card,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    label.toUpperCase(),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 10, color: AppColors.gray500),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    value,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w700,
                      color: valueColor,
                    ),
                  ),
                ],
              ),
            ),
            Container(height: 4, color: line),
          ],
        ),
      ),
    );
  }

  // --- Tab ---------------------------------------------------------------------

  Widget _tabs(Pal p) {
    Widget tab(String label, bool active, VoidCallback onTap) => Expanded(
          child: GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTap: onTap,
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 150),
              padding: const EdgeInsets.symmetric(vertical: 6),
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: active ? p.segActive : Colors.transparent,
                borderRadius: BorderRadius.circular(6),
                boxShadow: active ? shadowSm : null,
              ),
              child: Text(
                label,
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                  color: active ? AppColors.primary : AppColors.gray500,
                ),
              ),
            ),
          ),
        );

    return Container(
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: p.segBg,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        children: [
          tab('Bulan Ini', !_trend, () => setState(() => _trend = false)),
          tab('Tren 6 Bulan', _trend, () => setState(() => _trend = true)),
        ],
      ),
    );
  }

  // --- Grafik bulan ini (donat) -----------------------------------------------

  Widget _monthChart(Pal p, List<CategorySlice> pieData, int expense) {
    final title = Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Text(
        'Pengeluaran per Kategori',
        style: TextStyle(
          fontSize: 16,
          fontWeight: FontWeight.w600,
          color: p.text,
        ),
      ),
    );

    if (pieData.isEmpty) {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          title,
          const SizedBox(
            height: 256,
            child: Center(
              child: Text(
                'Belum ada data pengeluaran',
                style: TextStyle(color: AppColors.gray400),
              ),
            ),
          ),
        ],
      );
    }

    final touchedValid = _touched >= 0 && _touched < pieData.length;
    final centerLabel = touchedValid ? pieData[_touched].name : 'Total';
    final centerValue = touchedValid ? pieData[_touched].value : expense;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        title,
        SizedBox(
          height: 200,
          child: Stack(
            alignment: Alignment.center,
            children: [
              PieChart(
                PieChartData(
                  sectionsSpace: 2,
                  centerSpaceRadius: 60,
                  pieTouchData: PieTouchData(
                    touchCallback: (event, response) {
                      final idx = (!event.isInterestedForInteractions ||
                              response == null ||
                              response.touchedSection == null)
                          ? -1
                          : response.touchedSection!.touchedSectionIndex;
                      if (idx != _touched) {
                        setState(() => _touched = idx);
                      }
                    },
                  ),
                  sections: [
                    for (var i = 0; i < pieData.length; i++)
                      PieChartSectionData(
                        value: pieData[i].value.toDouble(),
                        color: pieData[i].color,
                        radius: _touched == i ? 24 : 20,
                        showTitle: false,
                      ),
                  ],
                ),
              ),
              IgnorePointer(
                child: SizedBox(
                  width: 104,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        centerLabel,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontSize: 10, color: AppColors.gray400),
                      ),
                      FittedBox(
                        fit: BoxFit.scaleDown,
                        child: Text(
                          formatRupiah(centerValue),
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w700,
                            color: p.text,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        Wrap(
          alignment: WrapAlignment.center,
          spacing: 16,
          runSpacing: 6,
          children: [
            for (final d in pieData)
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 8,
                    height: 8,
                    decoration: BoxDecoration(color: d.color, shape: BoxShape.circle),
                  ),
                  const SizedBox(width: 6),
                  Text(
                    d.name,
                    style: TextStyle(fontSize: 12, color: p.muted),
                  ),
                ],
              ),
          ],
        ),
      ],
    );
  }

  // --- Grafik tren 6 bulan (batang) -------------------------------------------

  Widget _trendChart(Pal p, List<_MonthBar> bars) {
    final maxVal = bars.fold<double>(
      0,
      (a, b) => math.max(a, math.max(b.income, b.expense).toDouble()),
    );
    final maxY = maxVal <= 0 ? 100.0 : maxVal * 1.2;

    const axisStyle = TextStyle(fontSize: 10, color: AppColors.gray500);

    Widget legend(String label, Color color) => Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 8,
              height: 8,
              decoration: BoxDecoration(color: color, shape: BoxShape.circle),
            ),
            const SizedBox(width: 6),
            Text(label, style: TextStyle(fontSize: 12, color: p.muted)),
          ],
        );

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text(
          'Arus Kas 6 Bulan',
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w600,
            color: p.text,
          ),
        ),
        const SizedBox(height: 16),
        SizedBox(
          height: 240,
          child: BarChart(
            BarChartData(
              maxY: maxY,
              alignment: BarChartAlignment.spaceAround,
              gridData: const FlGridData(show: false),
              borderData: FlBorderData(show: false),
              titlesData: FlTitlesData(
                topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                bottomTitles: AxisTitles(
                  sideTitles: SideTitles(
                    showTitles: true,
                    reservedSize: 28,
                    getTitlesWidget: (value, meta) {
                      final i = value.toInt();
                      if (i < 0 || i >= bars.length) return const SizedBox.shrink();
                      return Padding(
                        padding: const EdgeInsets.only(top: 8),
                        child: Text(bars[i].name, style: axisStyle),
                      );
                    },
                  ),
                ),
                leftTitles: AxisTitles(
                  sideTitles: SideTitles(
                    showTitles: true,
                    reservedSize: 40,
                    getTitlesWidget: (value, meta) => Padding(
                      padding: const EdgeInsets.only(right: 6),
                      child: Align(
                        alignment: Alignment.centerRight,
                        child: Text(compactNumber(value), style: axisStyle),
                      ),
                    ),
                  ),
                ),
              ),
              barTouchData: BarTouchData(
                touchTooltipData: BarTouchTooltipData(
                  getTooltipItem: (group, groupIndex, rod, rodIndex) =>
                      BarTooltipItem(
                    formatRupiah(rod.toY.round()),
                    const TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
              barGroups: [
                for (var i = 0; i < bars.length; i++)
                  BarChartGroupData(
                    x: i,
                    barsSpace: 4,
                    barRods: [
                      BarChartRodData(
                        toY: bars[i].income.toDouble(),
                        color: AppColors.emerald500,
                        width: 12,
                        borderRadius: const BorderRadius.vertical(top: Radius.circular(4)),
                      ),
                      BarChartRodData(
                        toY: bars[i].expense.toDouble(),
                        color: AppColors.red500,
                        width: 12,
                        borderRadius: const BorderRadius.vertical(top: Radius.circular(4)),
                      ),
                    ],
                  ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            legend('Masuk', AppColors.emerald500),
            const SizedBox(width: 16),
            legend('Keluar', AppColors.red500),
          ],
        ),
      ],
    );
  }

  // --- Rincian ---------------------------------------------------------------

  Widget _breakdownTile(Pal p, CategorySlice item, int expense) {
    final pct = expense > 0 ? item.value / expense * 100 : 0.0;
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: cardDecoration(p, radius: 12, shadow: false),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(
            child: Row(
              children: [
                Container(
                  width: 12,
                  height: 12,
                  decoration: BoxDecoration(color: item.color, shape: BoxShape.circle),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    item.name,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                      color: p.text2,
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                formatRupiah(item.value),
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w700,
                  color: p.text,
                ),
              ),
              Text(
                '${pct.toStringAsFixed(1)}%',
                style: const TextStyle(fontSize: 10, color: AppColors.gray400),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
