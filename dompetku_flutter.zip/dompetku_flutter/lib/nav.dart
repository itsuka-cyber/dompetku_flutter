import 'package:flutter/material.dart';

import 'pages/add_transaction.dart';
import 'pages/dashboard.dart';
import 'pages/goals.dart';
import 'pages/reports.dart';
import 'pages/settings.dart';
import 'pages/transactions.dart';

/// Rute tanpa animasi (perpindahan tab seperti di versi web).
Route<T> instantRoute<T>(Widget page) => PageRouteBuilder<T>(
      pageBuilder: (context, animation, secondaryAnimation) => page,
      transitionDuration: Duration.zero,
      reverseTransitionDuration: Duration.zero,
    );

/// Indeks tab: 0 Home, 1 Laporan, 2 Tambah, 3 Goals, 4 Settings.
void goTab(BuildContext context, int index, {int? current}) {
  if (index == current) return;

  final Widget page;
  switch (index) {
    case 0:
      page = const DashboardPage();
      break;
    case 1:
      page = const ReportsPage();
      break;
    case 2:
      openAdd(context);
      return;
    case 3:
      page = const GoalsPage();
      break;
    case 4:
      page = const SettingsPage();
      break;
    default:
      return;
  }

  Navigator.of(context).pushAndRemoveUntil(instantRoute<void>(page), (route) => false);
}

/// Halaman Tambah Transaksi (tanpa bottom nav).
void openAdd(BuildContext context) {
  Navigator.of(context).push(
    MaterialPageRoute<void>(builder: (_) => const AddTransactionPage()),
  );
}

/// Riwayat Transaksi (bottom nav tetap tampil, seperti versi web).
void openTransactions(BuildContext context) {
  Navigator.of(context).push(
    MaterialPageRoute<void>(builder: (_) => const TransactionsPage()),
  );
}
