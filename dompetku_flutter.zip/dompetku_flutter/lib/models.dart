import 'package:flutter/material.dart';

import 'utils.dart';

// Format JSON sengaja identik dengan versi web DompetKu, sehingga file backup
// dari aplikasi web bisa dipulihkan di aplikasi ini (dan sebaliknya).

class TxCategory {
  const TxCategory({
    required this.id,
    required this.name,
    required this.icon,
    required this.color,
    required this.type,
  });

  final String id;
  final String name;
  final String icon; // nama ikon, mis. "Utensils"
  final String color; // "#rrggbb"
  final String type; // 'income' | 'expense'

  Color get colorValue => parseHex(color);

  factory TxCategory.fromJson(Map<String, dynamic> j) => TxCategory(
        id: '${j['id']}',
        name: '${j['name'] ?? ''}',
        icon: '${j['icon'] ?? 'Circle'}',
        color: '${j['color'] ?? '#94a3b8'}',
        type: j['type'] == 'income' ? 'income' : 'expense',
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'icon': icon,
        'color': color,
        'type': type,
      };
}

class FinanceTransaction {
  const FinanceTransaction({
    required this.id,
    required this.amount,
    required this.categoryId,
    required this.type,
    required this.date,
    required this.note,
    this.imageUrl,
  });

  final String id;
  final int amount;
  final String categoryId;
  final String type; // 'income' | 'expense' | 'transfer'
  final String date; // ISO 8601
  final String note;
  final String? imageUrl;

  DateTime get dateTime => DateTime.tryParse(date)?.toLocal() ?? DateTime.now();

  factory FinanceTransaction.fromJson(Map<String, dynamic> j) =>
      FinanceTransaction(
        id: '${j['id']}',
        amount: asInt(j['amount']),
        categoryId: '${j['categoryId'] ?? ''}',
        type: j['type'] == 'income'
            ? 'income'
            : (j['type'] == 'transfer' ? 'transfer' : 'expense'),
        date: '${j['date'] ?? DateTime.now().toUtc().toIso8601String()}',
        note: '${j['note'] ?? ''}',
        imageUrl: j['imageUrl'] is String ? j['imageUrl'] as String : null,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'amount': amount,
        'categoryId': categoryId,
        'type': type,
        'date': date,
        'note': note,
        if (imageUrl != null) 'imageUrl': imageUrl,
      };
}

class SavingGoal {
  const SavingGoal({
    required this.id,
    required this.name,
    required this.targetAmount,
    required this.savedAmount,
    required this.deadline,
    required this.color,
  });

  final String id;
  final String name;
  final int targetAmount;
  final int savedAmount;
  final String deadline; // "yyyy-MM-dd"
  final String color; // "#rrggbb"

  Color get colorValue => parseHex(color);

  /// 0.0 - tak terbatas (dipakai apa adanya seperti versi web).
  double get ratio => targetAmount > 0 ? savedAmount / targetAmount : 0.0;

  SavingGoal copyWith({int? savedAmount}) => SavingGoal(
        id: id,
        name: name,
        targetAmount: targetAmount,
        savedAmount: savedAmount ?? this.savedAmount,
        deadline: deadline,
        color: color,
      );

  factory SavingGoal.fromJson(Map<String, dynamic> j) => SavingGoal(
        id: '${j['id']}',
        name: '${j['name'] ?? ''}',
        targetAmount: asInt(j['targetAmount']),
        savedAmount: asInt(j['savedAmount']),
        deadline: '${j['deadline'] ?? ''}',
        color: '${j['color'] ?? '#6366f1'}',
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'targetAmount': targetAmount,
        'savedAmount': savedAmount,
        'deadline': deadline,
        'color': color,
      };
}

class BudgetSetting {
  const BudgetSetting({required this.limit, required this.enabled});

  final int limit;
  final bool enabled;

  factory BudgetSetting.fromJson(Map<String, dynamic> j) => BudgetSetting(
        limit: asInt(j['limit']),
        enabled: j['enabled'] != false,
      );

  Map<String, dynamic> toJson() => {'limit': limit, 'enabled': enabled};
}

const List<TxCategory> defaultCategories = [
  TxCategory(id: 'cat_1', name: 'Makan & Minum', icon: 'Utensils', color: '#ef4444', type: 'expense'),
  TxCategory(id: 'cat_2', name: 'Transportasi', icon: 'Car', color: '#3b82f6', type: 'expense'),
  TxCategory(id: 'cat_3', name: 'Belanja', icon: 'ShoppingCart', color: '#f59e0b', type: 'expense'),
  TxCategory(id: 'cat_4', name: 'Hiburan', icon: 'Gamepad2', color: '#8b5cf6', type: 'expense'),
  TxCategory(id: 'cat_5', name: 'Tagihan', icon: 'Zap', color: '#eab308', type: 'expense'),
  TxCategory(id: 'cat_6', name: 'Kesehatan', icon: 'HeartPulse', color: '#ec4899', type: 'expense'),
  TxCategory(id: 'cat_7', name: 'Gaji', icon: 'Home', color: '#10b981', type: 'income'),
  TxCategory(id: 'cat_8', name: 'Investasi', icon: 'Coffee', color: '#6366f1', type: 'income'),
];

const BudgetSetting defaultBudget = BudgetSetting(limit: 300000, enabled: true);

class AppState {
  const AppState({
    required this.balance,
    required this.savings,
    required this.transactions,
    required this.categories,
    required this.goals,
    required this.budget,
    required this.isOnboarded,
    required this.darkMode,
    required this.userName,
  });

  final int balance;
  final int savings;
  final List<FinanceTransaction> transactions;
  final List<TxCategory> categories;
  final List<SavingGoal> goals;
  final BudgetSetting budget;
  final bool isOnboarded;
  final bool darkMode;
  final String userName;

  factory AppState.initial() => const AppState(
        balance: 0,
        savings: 0,
        transactions: [],
        categories: defaultCategories,
        goals: [],
        budget: defaultBudget,
        isOnboarded: false,
        darkMode: false,
        userName: '',
      );

  AppState copyWith({
    int? balance,
    int? savings,
    List<FinanceTransaction>? transactions,
    List<TxCategory>? categories,
    List<SavingGoal>? goals,
    BudgetSetting? budget,
    bool? isOnboarded,
    bool? darkMode,
    String? userName,
  }) =>
      AppState(
        balance: balance ?? this.balance,
        savings: savings ?? this.savings,
        transactions: transactions ?? this.transactions,
        categories: categories ?? this.categories,
        goals: goals ?? this.goals,
        budget: budget ?? this.budget,
        isOnboarded: isOnboarded ?? this.isOnboarded,
        darkMode: darkMode ?? this.darkMode,
        userName: userName ?? this.userName,
      );

  factory AppState.fromJson(Map<String, dynamic> j) {
    List<T> readList<T>(dynamic v, T Function(Map<String, dynamic>) build) {
      if (v is! List) return <T>[];
      return v
          .whereType<Map>()
          .map((e) => build(Map<String, dynamic>.from(e)))
          .toList();
    }

    return AppState(
      balance: asInt(j['balance']),
      savings: asInt(j['savings']),
      transactions:
          readList<FinanceTransaction>(j['transactions'], FinanceTransaction.fromJson),
      categories: j['categories'] is List
          ? readList<TxCategory>(j['categories'], TxCategory.fromJson)
          : defaultCategories,
      goals: readList<SavingGoal>(j['goals'], SavingGoal.fromJson),
      budget: j['budget'] is Map
          ? BudgetSetting.fromJson(Map<String, dynamic>.from(j['budget'] as Map))
          : defaultBudget,
      isOnboarded: j['isOnboarded'] == true,
      darkMode: j['darkMode'] == true,
      userName: '${j['userName'] ?? ''}',
    );
  }

  Map<String, dynamic> toJson() => {
        'balance': balance,
        'savings': savings,
        'transactions': transactions.map((t) => t.toJson()).toList(),
        'categories': categories.map((c) => c.toJson()).toList(),
        'goals': goals.map((g) => g.toJson()).toList(),
        'budget': budget.toJson(),
        'isOnboarded': isOnboarded,
        'darkMode': darkMode,
        'userName': userName,
      };
}

/// Satu irisan data untuk diagram donat.
class CategorySlice {
  const CategorySlice(this.name, this.value, this.color);

  final String name;
  final int value;
  final Color color;
}

TxCategory? findCategory(List<TxCategory> list, String id) {
  for (final c in list) {
    if (c.id == id) return c;
  }
  return null;
}
