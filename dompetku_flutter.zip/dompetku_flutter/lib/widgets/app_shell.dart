import 'package:flutter/material.dart';

import '../nav.dart';
import '../theme.dart';

/// Halaman dengan bottom navigation (setara <BottomNav /> di App.tsx).
/// [tab] = indeks tab aktif, atau null bila halaman bukan salah satu tab
/// (mis. Riwayat Transaksi).
class AppShell extends StatelessWidget {
  const AppShell({super.key, required this.child, this.tab});

  final Widget child;
  final int? tab;

  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    final keyboardOpen = MediaQuery.viewInsetsOf(context).bottom > 0;

    return Scaffold(
      backgroundColor: p.bg,
      body: SafeArea(bottom: false, child: child),
      bottomNavigationBar: keyboardOpen ? null : BottomNav(current: tab),
    );
  }
}

class _NavItem {
  const _NavItem(this.icon, this.label);

  final IconData icon;
  final String label;
}

class BottomNav extends StatelessWidget {
  const BottomNav({super.key, this.current});

  final int? current;

  static const List<_NavItem> _items = [
    _NavItem(Icons.dashboard_outlined, 'Home'),
    _NavItem(Icons.pie_chart_outline, 'Laporan'),
    _NavItem(Icons.add_circle_outline, 'Tambah'),
    _NavItem(Icons.track_changes, 'Goals'),
    _NavItem(Icons.settings_outlined, 'Settings'),
  ];

  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    final bottomInset = MediaQuery.paddingOf(context).bottom;

    return Container(
      padding: EdgeInsets.fromLTRB(8, 8, 8, bottomInset),
      decoration: BoxDecoration(
        color: p.card,
        border: Border(top: BorderSide(color: p.navBorder)),
      ),
      child: SizedBox(
        height: 64,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            for (var i = 0; i < _items.length; i++) _buildItem(context, p, i),
          ],
        ),
      ),
    );
  }

  Widget _buildItem(BuildContext context, Pal p, int index) {
    final item = _items[index];

    // Tombol tengah "Tambah": lingkaran gradien yang menonjol ke atas.
    if (index == 2) {
      return Transform.translate(
        offset: const Offset(0, -16),
        child: GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTap: () => goTab(context, 2, current: current),
          child: Container(
            width: 60,
            height: 60,
            decoration: BoxDecoration(
              gradient: primaryGradient,
              shape: BoxShape.circle,
              boxShadow: shadowGlow(AppColors.primary, .3),
            ),
            child: Icon(item.icon, size: 28, color: Colors.white),
          ),
        ),
      );
    }

    final active = current == index;
    final color = active
        ? AppColors.primary
        : (p.dark ? AppColors.slate500 : AppColors.gray400);

    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () => goTab(context, index, current: current),
      child: SizedBox(
        width: 48,
        height: 64,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(item.icon, size: 22, color: color),
            const SizedBox(height: 4),
            Text(
              item.label,
              maxLines: 1,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 9,
                height: 1,
                fontWeight: FontWeight.w500,
                color: color,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
