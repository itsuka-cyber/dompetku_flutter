import 'package:flutter/material.dart';

/// Peta nama ikon (sama dengan iconMap versi web, yang memakai Lucide)
/// ke ikon Material. Nama disimpan di data kategori & file backup, jadi
/// kuncinya harus tetap sama.
const Map<String, IconData> categoryIcons = {
  'Home': Icons.home_outlined,
  'ShoppingCart': Icons.shopping_cart_outlined,
  'Coffee': Icons.coffee_outlined,
  'Utensils': Icons.restaurant,
  'Car': Icons.directions_car_outlined,
  'Zap': Icons.bolt,
  'HeartPulse': Icons.favorite_border,
  'Gamepad2': Icons.sports_esports_outlined,
  'Gift': Icons.card_giftcard,
  'Briefcase': Icons.work_outline,
  'GraduationCap': Icons.school_outlined,
  'Smartphone': Icons.smartphone,
  'Plane': Icons.flight,
  'Wrench': Icons.build_outlined,
  'Shirt': Icons.checkroom_outlined,
  'Music': Icons.music_note,
  'Book': Icons.menu_book_outlined,
  'Landmark': Icons.account_balance_outlined,
  'Smile': Icons.sentiment_satisfied_alt_outlined,
  'Circle': Icons.circle_outlined,
  'Check': Icons.check,
};

IconData categoryIcon(String name) => categoryIcons[name] ?? Icons.help_outline;
