import 'package:flutter/material.dart';

/// Palet Tailwind yang sama dengan versi web.
class AppColors {
  AppColors._();

  // Brand (tailwind.config di index.html)
  static const primary = Color(0xFF6366F1);
  static const secondary = Color(0xFF8B5CF6);
  static const accent = Color(0xFF10B981);

  static const indigo100 = Color(0xFFE0E7FF);
  static const indigo200 = Color(0xFFC7D2FE);
  static const indigo600 = Color(0xFF4F46E5);
  static const indigo900 = Color(0xFF312E81);
  static const violet700 = Color(0xFF6D28D9);
  static const teal200 = Color(0xFF99F6E4);
  static const teal900 = Color(0xFF134E4A);

  static const emerald100 = Color(0xFFD1FAE5);
  static const emerald500 = Color(0xFF10B981);
  static const emerald600 = Color(0xFF059669);

  static const red100 = Color(0xFFFEE2E2);
  static const red500 = Color(0xFFEF4444);
  static const red600 = Color(0xFFDC2626);

  static const orange100 = Color(0xFFFFEDD5);
  static const orange500 = Color(0xFFF97316);
  static const orange600 = Color(0xFFEA580C);

  static const blue100 = Color(0xFFDBEAFE);
  static const blue500 = Color(0xFF3B82F6);
  static const blue600 = Color(0xFF2563EB);

  static const gray50 = Color(0xFFF9FAFB);
  static const gray100 = Color(0xFFF3F4F6);
  static const gray200 = Color(0xFFE5E7EB);
  static const gray300 = Color(0xFFD1D5DB);
  static const gray400 = Color(0xFF9CA3AF);
  static const gray500 = Color(0xFF6B7280);
  static const gray800 = Color(0xFF1F2937);
  static const gray900 = Color(0xFF111827);

  static const slate200 = Color(0xFFE2E8F0);
  static const slate300 = Color(0xFFCBD5E1);
  static const slate400 = Color(0xFF94A3B8);
  static const slate500 = Color(0xFF64748B);
  static const slate700 = Color(0xFF334155);
  static const slate800 = Color(0xFF1E293B);
  static const slate900 = Color(0xFF0F172A);
  static const slate950 = Color(0xFF020617);
}

/// Warna [c] dengan opacity [o] (0..1), tanpa withOpacity (agar bebas warning).
Color tint(Color c, double o) =>
    c.withAlpha((o.clamp(0.0, 1.0) * 255).round());

const LinearGradient primaryGradient = LinearGradient(
  begin: Alignment.topLeft,
  end: Alignment.bottomRight,
  colors: [AppColors.primary, AppColors.secondary],
);

const LinearGradient primaryGradientH = LinearGradient(
  begin: Alignment.centerLeft,
  end: Alignment.centerRight,
  colors: [AppColors.primary, AppColors.secondary],
);

/// shadow-sm
const List<BoxShadow> shadowSm = [
  BoxShadow(color: Color(0x0D000000), blurRadius: 3, offset: Offset(0, 1)),
  BoxShadow(
    color: Color(0x0D000000),
    blurRadius: 2,
    spreadRadius: -1,
    offset: Offset(0, 1),
  ),
];

/// shadow-lg / shadow-xl berwarna (mis. shadow-indigo-500/30)
List<BoxShadow> shadowGlow(
  Color c,
  double opacity, {
  double blur = 15,
  double dy = 10,
  double spread = -3,
}) =>
    [
      BoxShadow(
        color: tint(c, opacity),
        blurRadius: blur,
        spreadRadius: spread,
        offset: Offset(0, dy),
      ),
    ];

/// Warna yang berubah mengikuti mode terang/gelap (setara kelas `dark:` Tailwind).
class Pal {
  const Pal._(this.dark);

  final bool dark;

  factory Pal.of(BuildContext context) =>
      Pal._(Theme.of(context).brightness == Brightness.dark);

  /// Latar halaman: gray-50 / slate-950
  Color get bg => dark ? AppColors.slate950 : AppColors.gray50;

  /// Kartu: white / slate-900
  Color get card => dark ? AppColors.slate900 : Colors.white;

  /// Kartu level 2 (form transfer, toast): white / slate-800
  Color get card2 => dark ? AppColors.slate800 : Colors.white;

  /// Border kartu: gray-100 / slate-800
  Color get border => dark ? AppColors.slate800 : AppColors.gray100;

  /// Border input: gray-200 / slate-700
  Color get border2 => dark ? AppColors.slate700 : AppColors.gray200;

  /// Border bar navigasi: gray-200 / slate-800
  Color get navBorder => dark ? AppColors.slate800 : AppColors.gray200;

  /// Teks utama: gray-900 / white
  Color get text => dark ? Colors.white : AppColors.gray900;

  /// Label: (default) / slate-300
  Color get text2 => dark ? AppColors.slate300 : AppColors.gray900;

  /// Teks sekunder: gray-500 / slate-400
  Color get muted => dark ? AppColors.slate400 : AppColors.gray500;

  /// Placeholder & ikon pudar
  Color get faint => AppColors.gray400;

  /// Latar input (kartu gelap): gray-50 / slate-900
  Color get field => dark ? AppColors.slate900 : AppColors.gray50;

  /// Latar input (dalam kartu): gray-50 / slate-800
  Color get field2 => dark ? AppColors.slate800 : AppColors.gray50;

  /// Latar toggle segmented: gray-200 / slate-800
  Color get segBg => dark ? AppColors.slate800 : AppColors.gray200;

  /// Segmen aktif: white / slate-700
  Color get segActive => dark ? AppColors.slate700 : Colors.white;

  /// Track progress bar: gray-100 / slate-800
  Color get track => dark ? AppColors.slate800 : AppColors.gray100;

  /// Latar chip kecil / tombol ikon: gray-100 / slate-800
  Color get chip => dark ? AppColors.slate800 : AppColors.gray100;

  /// Tombol gelap (Lanjut, Simpan Budget): gray-900 / white
  Color get strongBg => dark ? Colors.white : AppColors.gray900;

  /// Teks pada tombol gelap: white / slate-900
  Color get strongFg => dark ? AppColors.slate900 : Colors.white;
}

/// Dekorasi kartu standar (rounded + border + shadow-sm).
BoxDecoration cardDecoration(
  Pal p, {
  double radius = 16,
  bool border = true,
  bool shadow = true,
  Color? color,
}) =>
    BoxDecoration(
      color: color ?? p.card,
      borderRadius: BorderRadius.circular(radius),
      border: border ? Border.all(color: p.border) : null,
      boxShadow: shadow ? shadowSm : null,
    );

class AppTheme {
  AppTheme._();

  static final ThemeData light = _build(Brightness.light);
  static final ThemeData dark = _build(Brightness.dark);

  static ThemeData _build(Brightness b) {
    final isDark = b == Brightness.dark;
    final text = isDark ? Colors.white : AppColors.gray900;

    final scheme = (isDark ? const ColorScheme.dark() : const ColorScheme.light())
        .copyWith(
      primary: AppColors.primary,
      secondary: AppColors.secondary,
      surface: isDark ? AppColors.slate900 : Colors.white,
    );

    final base = ThemeData(
      useMaterial3: true,
      brightness: b,
      fontFamily: 'Inter',
      colorScheme: scheme,
      scaffoldBackgroundColor: isDark ? AppColors.slate950 : AppColors.gray50,
      splashFactory: NoSplash.splashFactory,
      highlightColor: Colors.transparent,
      hoverColor: Colors.transparent,
      textSelectionTheme: TextSelectionThemeData(
        cursorColor: AppColors.primary,
        selectionColor: tint(AppColors.primary, .3),
        selectionHandleColor: AppColors.primary,
      ),
    );

    return base.copyWith(
      textTheme: base.textTheme.apply(bodyColor: text, displayColor: text),
    );
  }
}
