import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'package:provider/provider.dart';

import 'pages/dashboard.dart';
import 'pages/onboarding.dart';
import 'state/finance_store.dart';
import 'state/toast.dart';
import 'theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  await initializeDateFormatting('id_ID');
  final store = await FinanceStore.load();

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider<FinanceStore>.value(value: store),
        ChangeNotifierProvider<ToastController>(
          create: (_) => ToastController(),
        ),
      ],
      child: const DompetKuApp(),
    ),
  );
}

class DompetKuApp extends StatelessWidget {
  const DompetKuApp({super.key});

  @override
  Widget build(BuildContext context) {
    final dark = context.select<FinanceStore, bool>((s) => s.state.darkMode);

    return MaterialApp(
      title: 'DompetKu',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light,
      darkTheme: AppTheme.dark,
      themeMode: dark ? ThemeMode.dark : ThemeMode.light,
      locale: const Locale('id', 'ID'),
      supportedLocales: const [Locale('id', 'ID')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      builder: (context, child) {
        final isDark = Theme.of(context).brightness == Brightness.dark;
        return AnnotatedRegion<SystemUiOverlayStyle>(
          value: SystemUiOverlayStyle(
            statusBarColor: Colors.transparent,
            statusBarIconBrightness: isDark ? Brightness.light : Brightness.dark,
            systemNavigationBarColor:
                isDark ? AppColors.slate900 : Colors.white,
            systemNavigationBarIconBrightness:
                isDark ? Brightness.light : Brightness.dark,
          ),
          child: Stack(
            fit: StackFit.expand,
            children: [
              child ?? const SizedBox.shrink(),
              const ToastHost(),
            ],
          ),
        );
      },
      home: const RootGate(),
    );
  }
}

/// Setara ProtectedRoute: belum onboarding -> tampilkan Onboarding.
class RootGate extends StatelessWidget {
  const RootGate({super.key});

  @override
  Widget build(BuildContext context) {
    final onboarded =
        context.select<FinanceStore, bool>((s) => s.state.isOnboarded);
    return onboarded ? const DashboardPage() : const OnboardingPage();
  }
}
