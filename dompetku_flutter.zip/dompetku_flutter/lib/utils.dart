import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

// ---------------------------------------------------------------------------
// Format angka & tanggal (setara Intl id-ID di versi web)
// ---------------------------------------------------------------------------

final NumberFormat _decimalId = NumberFormat.decimalPattern('id_ID');

/// "Rp 1.250.000" (spasi non-breaking). Nilai negatif: "-Rp 1.000".
String formatRupiah(num amount) {
  final n = amount.round();
  final s = _decimalId.format(n.abs());
  return n < 0 ? '-Rp $s' : 'Rp $s';
}

/// 22/11/2026
String fmtDateShort(DateTime d) => DateFormat('d/M/y', 'id_ID').format(d);

/// Minggu, 22 November 2026
String fmtDateFull(DateTime d) =>
    DateFormat('EEEE, d MMMM y', 'id_ID').format(d);

/// Nov, Des, Agu ...
String fmtMonthShort(DateTime d) => DateFormat('MMM', 'id_ID').format(d);

/// 22/11/2026 (tampilan kolom tanggal)
String fmtDateInput(DateTime d) => DateFormat('dd/MM/yyyy').format(d);

/// 2026-11-22 (dipakai untuk deadline goal & nama file backup)
String isoDateOnly(DateTime d) => DateFormat('yyyy-MM-dd').format(d);

/// "budi santoso" -> "Budi Santoso" (setara CSS capitalize)
String capitalizeWords(String s) => s
    .split(' ')
    .map((w) => w.isEmpty ? w : '${w[0].toUpperCase()}${w.substring(1)}')
    .join(' ');

/// 5000000 -> "5jt", 250000 -> "250rb"
String compactNumber(num v) {
  if (v >= 1000000) {
    final m = v / 1000000;
    return '${m == m.roundToDouble() ? m.toInt() : m.toStringAsFixed(1)}jt';
  }
  if (v >= 1000) {
    final k = v / 1000;
    return '${k == k.roundToDouble() ? k.toInt() : k.toStringAsFixed(1)}rb';
  }
  return v.toInt().toString();
}

// ---------------------------------------------------------------------------
// ID & warna
// ---------------------------------------------------------------------------

final math.Random _rng = math.Random.secure();

/// UUID v4 (setara crypto.randomUUID()).
String newId() {
  final b = List<int>.generate(16, (_) => _rng.nextInt(256));
  b[6] = (b[6] & 0x0f) | 0x40;
  b[8] = (b[8] & 0x3f) | 0x80;
  String h(int i) => b[i].toRadixString(16).padLeft(2, '0');
  return '${h(0)}${h(1)}${h(2)}${h(3)}-${h(4)}${h(5)}-${h(6)}${h(7)}-'
      '${h(8)}${h(9)}-${h(10)}${h(11)}${h(12)}${h(13)}${h(14)}${h(15)}';
}

/// Warna acak dalam format "#rrggbb".
String randomHexColor() =>
    '#${_rng.nextInt(0x1000000).toRadixString(16).padLeft(6, '0')}';

/// "#ef4444" / "#f00" -> Color. Nilai rusak -> abu-abu slate-400.
Color parseHex(String hex) {
  var h = hex.trim().replaceFirst('#', '');
  if (h.length == 3) {
    h = h.split('').map((c) => '$c$c').join();
  }
  if (h.length > 6) {
    h = h.substring(h.length - 6);
  }
  h = h.padLeft(6, '0');
  final v = int.tryParse(h, radix: 16);
  if (v == null) return const Color(0xFF94A3B8);
  return Color(0xFF000000 | v);
}

/// Membatasi nilai ke rentang 0.0 - 1.0 (hasilnya selalu double).
double clamp01(double v) => math.min(1.0, math.max(0.0, v));

/// Mengubah JSON number/string apa pun menjadi int.
int asInt(dynamic v) {
  if (v is num) return v.round();
  return int.tryParse('$v') ?? 0;
}
