import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../theme.dart';
import '../utils.dart';

enum ToastType { success, error, info }

class ToastMessage {
  const ToastMessage(this.id, this.message, this.type);

  final String id;
  final String message;
  final ToastType type;
}

/// Setara ToastContext di versi web: notifikasi kecil di atas layar, hilang
/// otomatis setelah 3 detik.
class ToastController extends ChangeNotifier {
  final List<ToastMessage> _toasts = [];

  List<ToastMessage> get toasts => List.unmodifiable(_toasts);

  void show(String message, [ToastType type = ToastType.success]) {
    final id = newId();
    _toasts.add(ToastMessage(id, message, type));
    notifyListeners();
    Timer(const Duration(seconds: 3), () => remove(id));
  }

  void remove(String id) {
    final before = _toasts.length;
    _toasts.removeWhere((t) => t.id == id);
    if (_toasts.length != before) notifyListeners();
  }
}

extension ToastContext on BuildContext {
  void showToast(String message, [ToastType type = ToastType.success]) =>
      Provider.of<ToastController>(this, listen: false).show(message, type);
}

/// Dipasang di MaterialApp.builder, di atas semua halaman.
class ToastHost extends StatelessWidget {
  const ToastHost({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = context.watch<ToastController>();
    final top = MediaQuery.paddingOf(context).top + 16;

    return Positioned(
      top: top,
      left: 0,
      right: 0,
      child: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 320),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                for (final t in controller.toasts)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: _ToastCard(key: ValueKey(t.id), toast: t),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _ToastCard extends StatelessWidget {
  const _ToastCard({super.key, required this.toast});

  final ToastMessage toast;

  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    final dark = p.dark;

    late final Color fg;
    late final Color border;
    late final Color iconBg;
    late final IconData icon;

    switch (toast.type) {
      case ToastType.success:
        fg = dark ? const Color(0xFF34D399) : AppColors.emerald600;
        border = dark ? tint(const Color(0xFF064E3B), .3) : AppColors.emerald100;
        iconBg = dark ? tint(const Color(0xFF064E3B), .3) : AppColors.emerald100;
        icon = Icons.check_circle_outline;
        break;
      case ToastType.error:
        fg = dark ? const Color(0xFFF87171) : AppColors.red600;
        border = dark ? tint(const Color(0xFF7F1D1D), .3) : AppColors.red100;
        iconBg = dark ? tint(const Color(0xFF7F1D1D), .3) : AppColors.red100;
        icon = Icons.error_outline;
        break;
      case ToastType.info:
        fg = dark ? const Color(0xFF60A5FA) : AppColors.blue600;
        border = dark ? tint(const Color(0xFF1E3A8A), .3) : AppColors.blue100;
        iconBg = dark ? tint(const Color(0xFF1E3A8A), .3) : AppColors.blue100;
        icon = Icons.info_outline;
        break;
    }

    return TweenAnimationBuilder<double>(
      tween: Tween<double>(begin: 0, end: 1),
      duration: const Duration(milliseconds: 300),
      curve: Curves.easeOut,
      builder: (context, v, child) => Opacity(
        opacity: v,
        child: Transform.translate(offset: Offset(0, (1 - v) * -20), child: child),
      ),
      child: Material(
        color: p.card2,
        elevation: 6,
        shadowColor: Colors.black38,
        borderRadius: BorderRadius.circular(12),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: border),
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(4),
                decoration: BoxDecoration(color: iconBg, shape: BoxShape.circle),
                child: Icon(icon, size: 16, color: fg),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  toast.message,
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                    color: dark ? Colors.white : AppColors.gray800,
                  ),
                ),
              ),
              const SizedBox(width: 12),
              GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: () => context.read<ToastController>().remove(toast.id),
                child: const Icon(Icons.close, size: 16, color: AppColors.gray400),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
