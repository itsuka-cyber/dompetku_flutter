import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models.dart';

/// Setara FinanceContext + reducer di versi web.
/// Data disimpan lokal (SharedPreferences) pada setiap perubahan.
class FinanceStore extends ChangeNotifier {
  FinanceStore._(this._state, this._prefs);

  static const String storageKey = 'dompetku_offline_data_v1';

  final SharedPreferences _prefs;
  AppState _state;

  AppState get state => _state;

  static Future<FinanceStore> load() async {
    final prefs = await SharedPreferences.getInstance();
    var s = AppState.initial();
    final saved = prefs.getString(storageKey);
    if (saved != null) {
      try {
        s = AppState.fromJson(jsonDecode(saved) as Map<String, dynamic>);
      } catch (e) {
        debugPrint('Gagal membaca data tersimpan: $e');
      }
    }
    return FinanceStore._(s, prefs);
  }

  void _commit(AppState next) {
    _state = next;
    notifyListeners();
    _prefs.setString(storageKey, jsonEncode(_state.toJson()));
  }

  // --- Transaksi -----------------------------------------------------------

  void addTransaction(FinanceTransaction t) {
    var balance = _state.balance;
    if (t.type == 'income') {
      balance += t.amount;
    } else if (t.type == 'expense') {
      balance -= t.amount;
    }
    _commit(_state.copyWith(
      balance: balance,
      transactions: [t, ..._state.transactions],
    ));
  }

  void deleteTransaction(String id) {
    FinanceTransaction? t;
    for (final x in _state.transactions) {
      if (x.id == id) {
        t = x;
        break;
      }
    }
    if (t == null) return;

    var balance = _state.balance;
    if (t.type == 'income') {
      balance -= t.amount;
    } else if (t.type == 'expense') {
      balance += t.amount;
    }
    _commit(_state.copyWith(
      balance: balance,
      transactions: _state.transactions.where((x) => x.id != id).toList(),
    ));
  }

  // --- Goal ----------------------------------------------------------------

  void addGoal(SavingGoal g) =>
      _commit(_state.copyWith(goals: [..._state.goals, g]));

  void updateGoal(SavingGoal g) => _commit(_state.copyWith(
        goals: _state.goals.map((x) => x.id == g.id ? g : x).toList(),
      ));

  void deleteGoal(String id) => _commit(_state.copyWith(
        goals: _state.goals.where((x) => x.id != id).toList(),
      ));

  // --- Lain-lain -----------------------------------------------------------

  void completeOnboarding(String name) =>
      _commit(_state.copyWith(isOnboarded: true, userName: name));

  void toggleDarkMode() =>
      _commit(_state.copyWith(darkMode: !_state.darkMode));

  /// amount > 0: pindah ke tabungan. amount < 0: tarik dari tabungan.
  void transferToSavings(int amount) => _commit(_state.copyWith(
        balance: _state.balance - amount,
        savings: _state.savings + amount,
      ));

  void setBudget(BudgetSetting b) => _commit(_state.copyWith(budget: b));

  void addCategory(TxCategory c) =>
      _commit(_state.copyWith(categories: [..._state.categories, c]));

  void restoreData(AppState s) => _commit(s);

  /// Hapus semua data (kembali ke onboarding).
  Future<void> resetAll() async {
    _state = AppState.initial();
    notifyListeners();
    await _prefs.remove(storageKey);
  }
}
